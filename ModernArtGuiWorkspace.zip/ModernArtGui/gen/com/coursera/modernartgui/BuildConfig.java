/** Automatically generated file. DO NOT MODIFY */
package com.coursera.modernartgui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}